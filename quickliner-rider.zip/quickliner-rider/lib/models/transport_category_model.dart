import 'package:flutter/material.dart';

class TransportCategoryModel{
  String transportName;
  String transportImage;
  Route route;

  TransportCategoryModel({required this.transportImage,required this.transportName,required this.route});
}