import 'package:flutter/material.dart';

class AppColors{
  Color primaryColor=Colors.teal;
  Color whiteColor=Colors.white;
  Color blackColor=Colors.black;
  Color greenAccentColor=Colors.greenAccent;
}