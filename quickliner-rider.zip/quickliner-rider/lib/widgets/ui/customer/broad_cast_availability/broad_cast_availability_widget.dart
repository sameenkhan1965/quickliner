import 'package:flutter/material.dart';

class BroadCastAvailablility extends StatefulWidget {
  const BroadCastAvailablility({Key? key}) : super(key: key);

  @override
  State<BroadCastAvailablility> createState() => _BroadCastAvailablilityState();
}

class _BroadCastAvailablilityState extends State<BroadCastAvailablility> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
